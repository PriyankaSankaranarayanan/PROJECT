/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Alphabet from './pages/Alphabet';
import Practice from './pages/Practice';
import Words from './pages/Words';
import Sentences from './pages/Sentences';
import Dashboard from './pages/Dashboard';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="alphabet" element={<Alphabet />} />
          <Route path="practice/:letter" element={<Practice />} />
          <Route path="words" element={<Words />} />
          <Route path="sentences" element={<Sentences />} />
          <Route path="dashboard" element={<Dashboard />} />
        </Route>
      </Routes>
    </Router>
  );
}
