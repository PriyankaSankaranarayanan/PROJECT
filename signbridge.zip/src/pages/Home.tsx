import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, BookA, MessageSquare, ListVideo } from 'lucide-react';

export default function Home() {
  return (
    <div className="max-w-5xl mx-auto px-8 py-12">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center max-w-3xl mx-auto mb-16"
      >
        <h1 className="text-5xl font-extrabold tracking-tight text-neutral-900 mb-6">
          Learn Indian Sign Language <br/>
          <span className="text-blue-600">Interactively</span>
        </h1>
        <p className="text-lg text-neutral-600 leading-relaxed">
          SignBridge uses your webcam and real-time AI to give you instant feedback on your hand gestures. Start learning ISL today with our 3D virtual instructor.
        </p>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-6">
        {[
          {
            title: "Alphabets",
            desc: "Master the A-Z of Indian Sign Language with real-time feedback.",
            icon: BookA,
            path: "/alphabet",
            color: "bg-blue-50 text-blue-600",
            border: "border-blue-100"
          },
          {
            title: "Words",
            desc: "Learn common words and phrases used in daily conversations.",
            icon: MessageSquare,
            path: "/words",
            color: "bg-green-50 text-green-600",
            border: "border-green-100"
          },
          {
            title: "Sentences",
            desc: "Combine words to form complete sentences and practice flow.",
            icon: ListVideo,
            path: "/sentences",
            color: "bg-purple-50 text-purple-600",
            border: "border-purple-100"
          }
        ].map((card, i) => (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Link 
              to={card.path}
              className={`block p-8 rounded-3xl border ${card.border} bg-white hover:shadow-xl transition-all duration-300 group`}
            >
              <div className={`w-14 h-14 rounded-2xl ${card.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                <card.icon className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-neutral-900 mb-3">{card.title}</h3>
              <p className="text-neutral-500 mb-6">{card.desc}</p>
              <div className="flex items-center text-sm font-semibold text-neutral-900 group-hover:text-blue-600 transition-colors">
                Start Learning <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
