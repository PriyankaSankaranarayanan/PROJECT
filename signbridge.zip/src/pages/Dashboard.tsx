import { useStore } from '../store/useStore';
import { Trophy, Flame, Star } from 'lucide-react';

export default function Dashboard() {
  const { score, streak } = useStore();

  return (
    <div className="max-w-6xl mx-auto px-8 py-12">
      <div className="mb-10">
        <h1 className="text-3xl font-bold text-neutral-900 mb-2">Your Dashboard</h1>
        <p className="text-neutral-500">Track your learning progress and achievements.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 mb-12">
        <div className="bg-white p-6 rounded-3xl border border-neutral-200 flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
            <Trophy className="w-6 h-6" />
          </div>
          <div>
            <div className="text-sm font-medium text-neutral-500">Total Score</div>
            <div className="text-2xl font-bold text-neutral-900">{score}</div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-neutral-200 flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-orange-50 flex items-center justify-center text-orange-500">
            <Flame className="w-6 h-6" />
          </div>
          <div>
            <div className="text-sm font-medium text-neutral-500">Current Streak</div>
            <div className="text-2xl font-bold text-neutral-900">{streak} Days</div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-neutral-200 flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-yellow-50 flex items-center justify-center text-yellow-500">
            <Star className="w-6 h-6" />
          </div>
          <div>
            <div className="text-sm font-medium text-neutral-500">Level</div>
            <div className="text-2xl font-bold text-neutral-900">Beginner</div>
          </div>
        </div>
      </div>
      
      <div className="bg-white p-8 rounded-3xl border border-neutral-200">
        <h2 className="text-xl font-bold text-neutral-900 mb-6">Recent Activity</h2>
        <div className="text-neutral-500 text-center py-8">
          Start practicing to see your activity here.
        </div>
      </div>
    </div>
  );
}
