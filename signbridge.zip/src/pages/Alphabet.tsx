import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import gestures from '../data/gestures.json';

export default function Alphabet() {
  const letters = Object.keys(gestures);

  return (
    <div className="max-w-6xl mx-auto px-8 py-12">
      <div className="mb-10">
        <h1 className="text-3xl font-bold text-neutral-900 mb-2">Learn Alphabets</h1>
        <p className="text-neutral-500">Select a letter to start practicing its gesture.</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {letters.map((letter, i) => (
          <motion.div
            key={letter}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.02 }}
          >
            <Link
              to={`/practice/${letter}`}
              className="flex flex-col items-center justify-center aspect-square bg-white border border-neutral-200 rounded-2xl hover:border-blue-500 hover:shadow-lg hover:text-blue-600 transition-all group"
            >
              <span className="text-4xl font-black text-neutral-800 group-hover:text-blue-600 transition-colors mb-2">
                {letter}
              </span>
              <span className="text-xs font-medium text-neutral-400 group-hover:text-blue-400">
                Practice
              </span>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
