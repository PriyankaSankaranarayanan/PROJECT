import { motion } from 'framer-motion';

export default function Words() {
  return (
    <div className="max-w-6xl mx-auto px-8 py-12">
      <div className="mb-10">
        <h1 className="text-3xl font-bold text-neutral-900 mb-2">Learn Words</h1>
        <p className="text-neutral-500">Practice common words in Indian Sign Language.</p>
      </div>
      <div className="bg-white p-12 rounded-3xl border border-neutral-200 text-center">
        <h2 className="text-2xl font-bold text-neutral-400 mb-4">Coming Soon</h2>
        <p className="text-neutral-500">We are currently building the words module. Stay tuned!</p>
      </div>
    </div>
  );
}
