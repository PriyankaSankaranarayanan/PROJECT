import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, CheckCircle, XCircle } from 'lucide-react';
import { useHandTracking } from '../hooks/useHandTracking';
import { determineFingerStates, compareGestures } from '../utils/gestureLogic';
import gesturesData from '../data/gestures.json';
import Hand3D from '../components/Hand3D';
import { useStore } from '../store/useStore';

export default function Practice() {
  const { letter } = useParams();
  const { videoRef, results, isLoaded } = useHandTracking();
  const targetGesture = (gesturesData as any)[letter || 'A'];
  const { addScore } = useStore();

  const [feedback, setFeedback] = useState<any>(null);
  const [isCorrect, setIsCorrect] = useState(false);
  const [hasScored, setHasScored] = useState(false);

  useEffect(() => {
    if (results && results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
      const landmarks = results.multiHandLandmarks[0];
      const detected = determineFingerStates(landmarks);
      const comparison = compareGestures(detected, targetGesture);
      
      setFeedback(comparison.feedback);
      setIsCorrect(comparison.isCorrect);

      if (comparison.isCorrect && !hasScored) {
        addScore(10);
        setHasScored(true);
        // Optional: Play success sound or voice feedback
        if ('speechSynthesis' in window) {
          const msg = new SpeechSynthesisUtterance("Correct!");
          window.speechSynthesis.speak(msg);
        }
      }
    } else {
      setFeedback(null);
      setIsCorrect(false);
    }
  }, [results, targetGesture, hasScored, addScore]);

  if (!targetGesture) return <div>Gesture not found</div>;

  return (
    <div className="max-w-7xl mx-auto px-8 py-8 h-full flex flex-col">
      <div className="flex items-center mb-6">
        <Link to="/alphabet" className="p-2 hover:bg-neutral-200 rounded-full transition-colors mr-4">
          <ArrowLeft className="w-6 h-6 text-neutral-600" />
        </Link>
        <h1 className="text-3xl font-bold text-neutral-900">Practice: {letter}</h1>
      </div>

      <div className="flex-1 grid lg:grid-cols-2 gap-8 min-h-0">
        {/* Left: Instructions & 3D Instructor */}
        <div className="flex flex-col gap-6">
          <div className="bg-white p-6 rounded-3xl border border-neutral-200 shadow-sm">
            <h2 className="text-xl font-bold text-neutral-900 mb-4">Instructions</h2>
            <p className="text-neutral-600 text-lg mb-6">{targetGesture.instruction}</p>
            
            <div className="grid grid-cols-5 gap-2 text-center">
              {['Thumb', 'Index', 'Middle', 'Ring', 'Pinky'].map((finger) => {
                const key = finger.toLowerCase();
                const isOpen = targetGesture[key];
                return (
                  <div key={finger} className={`p-3 rounded-xl border ${isOpen ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-neutral-50 border-neutral-200 text-neutral-500'}`}>
                    <div className="text-xs font-bold uppercase tracking-wider mb-1">{finger}</div>
                    <div className="text-sm">{isOpen ? 'Open' : 'Fold'}</div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="flex-1 min-h-[300px]">
            <Hand3D targetGesture={targetGesture} />
          </div>
        </div>

        {/* Right: Webcam & Feedback */}
        <div className="flex flex-col gap-6">
          <div className="relative flex-1 bg-black rounded-3xl overflow-hidden shadow-lg">
            {!isLoaded && (
              <div className="absolute inset-0 flex items-center justify-center text-white z-10 bg-neutral-900">
                Loading Camera & AI Model...
              </div>
            )}
            <video
              ref={videoRef}
              className="absolute inset-0 w-full h-full object-cover transform scale-x-[-1]"
              playsInline
            />
            
            {/* Overlay Feedback */}
            {isCorrect && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute inset-0 border-8 border-green-500 rounded-3xl pointer-events-none"
              />
            )}
          </div>

          <div className="bg-white p-6 rounded-3xl border border-neutral-200 shadow-sm">
            <h2 className="text-xl font-bold text-neutral-900 mb-4">Real-Time Feedback</h2>
            
            {feedback ? (
              <div className="space-y-4">
                {isCorrect ? (
                  <div className="flex items-center text-green-600 bg-green-50 p-4 rounded-xl">
                    <CheckCircle className="w-6 h-6 mr-3" />
                    <span className="font-bold text-lg">Perfect! You got it right.</span>
                  </div>
                ) : (
                  <div className="grid grid-cols-5 gap-2 text-center">
                    {['Thumb', 'Index', 'Middle', 'Ring', 'Pinky'].map((finger) => {
                      const key = finger.toLowerCase();
                      const isFingerCorrect = feedback[key];
                      return (
                        <div key={finger} className={`p-2 rounded-xl border ${isFingerCorrect ? 'bg-green-50 border-green-200 text-green-700' : 'bg-red-50 border-red-200 text-red-700'}`}>
                          <div className="text-xs font-bold uppercase tracking-wider mb-1">{finger}</div>
                          {isFingerCorrect ? <CheckCircle className="w-5 h-5 mx-auto" /> : <XCircle className="w-5 h-5 mx-auto" />}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            ) : (
              <div className="text-neutral-500 text-center py-4">
                Show your hand to the camera to get feedback.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
