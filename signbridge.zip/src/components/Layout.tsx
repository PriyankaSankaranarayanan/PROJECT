import { Outlet, Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Home, BookA, MessageSquare, ListVideo, LayoutDashboard } from 'lucide-react';
import { cn } from '../lib/utils';
import { useStore } from '../store/useStore';

const navItems = [
  { path: '/', icon: Home, label: 'Home' },
  { path: '/alphabet', icon: BookA, label: 'Alphabets' },
  { path: '/words', icon: MessageSquare, label: 'Words' },
  { path: '/sentences', icon: ListVideo, label: 'Sentences' },
  { path: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
];

export default function Layout() {
  const location = useLocation();
  const { score, streak } = useStore();

  return (
    <div className="flex h-screen bg-neutral-50 text-neutral-900 font-sans overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-neutral-200 flex flex-col">
        <div className="p-6">
          <h1 className="text-2xl font-bold tracking-tight text-blue-600">SignBridge</h1>
          <p className="text-sm text-neutral-500 mt-1">ISL Learning Companion</p>
        </div>

        <nav className="flex-1 px-4 space-y-2">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path || (item.path !== '/' && location.pathname.startsWith(item.path));
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200",
                  isActive 
                    ? "bg-blue-50 text-blue-700 font-medium" 
                    : "text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900"
                )}
              >
                <item.icon className={cn("w-5 h-5", isActive ? "text-blue-600" : "text-neutral-400")} />
                {item.label}
                {isActive && (
                  <motion.div
                    layoutId="activeNav"
                    className="absolute left-0 w-1 h-8 bg-blue-600 rounded-r-full"
                    initial={false}
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
              </Link>
            );
          })}
        </nav>

        <div className="p-6 border-t border-neutral-100">
          <div className="bg-neutral-50 rounded-xl p-4 border border-neutral-200">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-neutral-600">Score</span>
              <span className="text-sm font-bold text-blue-600">{score} pts</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-neutral-600">Streak</span>
              <span className="text-sm font-bold text-orange-500">{streak} days 🔥</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto bg-neutral-50 relative">
        <Outlet />
      </main>
    </div>
  );
}
