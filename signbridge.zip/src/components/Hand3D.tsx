import { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Environment } from '@react-three/drei';
import * as THREE from 'three';

interface Hand3DProps {
  targetGesture: any;
}

function Finger({ position, rotation, length, color = "#ffccaa" }: any) {
  return (
    <group position={position} rotation={rotation}>
      <mesh position={[0, length / 2, 0]}>
        <cylinderGeometry args={[0.2, 0.2, length, 16]} />
        <meshStandardMaterial color={color} roughness={0.4} />
      </mesh>
      <mesh position={[0, length, 0]}>
        <sphereGeometry args={[0.2, 16, 16]} />
        <meshStandardMaterial color={color} roughness={0.4} />
      </mesh>
    </group>
  );
}

function HandModel({ targetGesture }: { targetGesture: any }) {
  const group = useRef<THREE.Group>(null);

  // Animate based on targetGesture
  useFrame(() => {
    if (!group.current || !targetGesture) return;
    
    // Smoothly interpolate rotations
    const lerpFactor = 0.1;
    
    // Index 1 (Index finger)
    const indexRot = targetGesture.index ? 0 : Math.PI / 2;
    group.current.children[1].rotation.x += (indexRot - group.current.children[1].rotation.x) * lerpFactor;

    // Index 2 (Middle)
    const middleRot = targetGesture.middle ? 0 : Math.PI / 2;
    group.current.children[2].rotation.x += (middleRot - group.current.children[2].rotation.x) * lerpFactor;

    // Index 3 (Ring)
    const ringRot = targetGesture.ring ? 0 : Math.PI / 2;
    group.current.children[3].rotation.x += (ringRot - group.current.children[3].rotation.x) * lerpFactor;

    // Index 4 (Pinky)
    const pinkyRot = targetGesture.pinky ? 0 : Math.PI / 2;
    group.current.children[4].rotation.x += (pinkyRot - group.current.children[4].rotation.x) * lerpFactor;

    // Index 5 (Thumb)
    const thumbRotZ = targetGesture.thumb ? -Math.PI / 4 : 0;
    const thumbRotX = targetGesture.thumb ? 0 : Math.PI / 4;
    group.current.children[5].rotation.z += (thumbRotZ - group.current.children[5].rotation.z) * lerpFactor;
    group.current.children[5].rotation.x += (thumbRotX - group.current.children[5].rotation.x) * lerpFactor;
  });

  return (
    <group ref={group} position={[0, -1, 0]}>
      {/* Palm */}
      <mesh position={[0, 1, 0]}>
        <boxGeometry args={[2, 2, 0.5]} />
        <meshStandardMaterial color="#ffccaa" roughness={0.4} />
      </mesh>

      {/* Fingers */}
      <Finger position={[-0.75, 2, 0]} length={1.5} /> {/* Index */}
      <Finger position={[-0.25, 2, 0]} length={1.7} /> {/* Middle */}
      <Finger position={[0.25, 2, 0]} length={1.6} /> {/* Ring */}
      <Finger position={[0.75, 2, 0]} length={1.3} /> {/* Pinky */}
      
      {/* Thumb */}
      <group position={[-1, 0.5, 0]} rotation={[0, 0, -Math.PI / 4]}>
        <Finger position={[0, 0, 0]} length={1.2} />
      </group>
    </group>
  );
}

export default function Hand3D({ targetGesture }: Hand3DProps) {
  return (
    <div className="w-full h-full bg-neutral-100 rounded-2xl overflow-hidden relative">
      <Canvas camera={{ position: [0, 2, 5], fov: 50 }}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[10, 10, 5]} intensity={1} />
        <Environment preset="city" />
        <HandModel targetGesture={targetGesture} />
        <OrbitControls enableZoom={false} />
      </Canvas>
      <div className="absolute bottom-4 left-4 right-4 text-center text-xs text-neutral-400 font-medium bg-white/80 backdrop-blur py-2 rounded-lg">
        3D Virtual Instructor (Drag to rotate)
      </div>
    </div>
  );
}
