import { create } from 'zustand';

interface User {
  id: number;
  username: string;
}

interface AppState {
  user: User | null;
  token: string | null;
  score: number;
  streak: number;
  setUser: (user: User | null, token: string | null) => void;
  addScore: (points: number) => void;
  incrementStreak: () => void;
  resetStreak: () => void;
}

export const useStore = create<AppState>((set) => ({
  user: null,
  token: localStorage.getItem('token'),
  score: 0,
  streak: 0,
  setUser: (user, token) => {
    if (token) {
      localStorage.setItem('token', token);
    } else {
      localStorage.removeItem('token');
    }
    set({ user, token });
  },
  addScore: (points) => set((state) => ({ score: state.score + points })),
  incrementStreak: () => set((state) => ({ streak: state.streak + 1 })),
  resetStreak: () => set({ streak: 0 }),
}));
