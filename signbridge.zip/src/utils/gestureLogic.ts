import { NormalizedLandmarkList } from '@mediapipe/hands';

export interface FingerStates {
  thumb: boolean;
  index: boolean;
  middle: boolean;
  ring: boolean;
  pinky: boolean;
}

export function determineFingerStates(landmarks: NormalizedLandmarkList): FingerStates {
  // Landmarks indices:
  // Thumb: 1, 2, 3, 4
  // Index: 5, 6, 7, 8
  // Middle: 9, 10, 11, 12
  // Ring: 13, 14, 15, 16
  // Pinky: 17, 18, 19, 20

  const isFingerOpen = (tipIdx: number, pipIdx: number) => {
    return landmarks[tipIdx].y < landmarks[pipIdx].y;
  };

  // Thumb is special, compare x coordinates (assuming right hand for simplicity, though should handle both)
  // A simple heuristic for thumb: tip x is further from pinky base x than mcp x
  const isThumbOpen = () => {
    // For right hand, thumb tip x < mcp x. For left hand, tip x > mcp x.
    // Let's use distance from palm center (0) or just simple y comparison if pointing up
    // A better heuristic for thumb openness: distance between thumb tip (4) and index mcp (5)
    const dist = Math.hypot(landmarks[4].x - landmarks[5].x, landmarks[4].y - landmarks[5].y);
    return dist > 0.1; // threshold
  };

  return {
    thumb: isThumbOpen(),
    index: isFingerOpen(8, 6),
    middle: isFingerOpen(12, 10),
    ring: isFingerOpen(16, 14),
    pinky: isFingerOpen(20, 18),
  };
}

export function compareGestures(detected: FingerStates, target: any) {
  const feedback = {
    thumb: detected.thumb === target.thumb,
    index: detected.index === target.index,
    middle: detected.middle === target.middle,
    ring: detected.ring === target.ring,
    pinky: detected.pinky === target.pinky,
  };

  const isCorrect = Object.values(feedback).every(Boolean);
  
  return { feedback, isCorrect };
}
