import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import sqlite3 from 'sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import cors from 'cors';

const JWT_SECRET = process.env.JWT_SECRET || 'signbridge-secret-key';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());
  app.use(cors());

  // Initialize SQLite Database
  const db = new sqlite3.Database('./signbridge.db', (err) => {
    if (err) {
      console.error('Error opening database', err);
    } else {
      db.run(`
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT UNIQUE,
          password TEXT
        )
      `);
      db.run(`
        CREATE TABLE IF NOT EXISTS progress (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER,
          lesson TEXT,
          score INTEGER,
          FOREIGN KEY(user_id) REFERENCES users(id)
        )
      `);
    }
  });

  // Auth Middleware
  const authenticateToken = (req: any, res: any, next: any) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (token == null) return res.sendStatus(401);

    jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
      if (err) return res.sendStatus(403);
      req.user = user;
      next();
    });
  };

  // API Routes
  app.post('/api/signup', (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required' });
    }

    const hashedPassword = bcrypt.hashSync(password, 10);
    db.run('INSERT INTO users (username, password) VALUES (?, ?)', [username, hashedPassword], function (err) {
      if (err) {
        return res.status(400).json({ error: 'Username already exists' });
      }
      const token = jwt.sign({ id: this.lastID, username }, JWT_SECRET);
      res.json({ token, user: { id: this.lastID, username } });
    });
  });

  app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    db.get('SELECT * FROM users WHERE username = ?', [username], (err, user: any) => {
      if (err || !user) {
        return res.status(400).json({ error: 'Invalid credentials' });
      }
      if (bcrypt.compareSync(password, user.password)) {
        const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET);
        res.json({ token, user: { id: user.id, username: user.username } });
      } else {
        res.status(400).json({ error: 'Invalid credentials' });
      }
    });
  });

  app.get('/api/progress', authenticateToken, (req: any, res) => {
    db.all('SELECT lesson, MAX(score) as score FROM progress WHERE user_id = ? GROUP BY lesson', [req.user.id], (err, rows) => {
      if (err) {
        return res.status(500).json({ error: 'Failed to fetch progress' });
      }
      res.json(rows);
    });
  });

  app.post('/api/progress', authenticateToken, (req: any, res) => {
    const { lesson, score } = req.body;
    db.run('INSERT INTO progress (user_id, lesson, score) VALUES (?, ?, ?)', [req.user.id, lesson, score], function (err) {
      if (err) {
        return res.status(500).json({ error: 'Failed to save progress' });
      }
      res.json({ success: true, id: this.lastID });
    });
  });

  app.get('/api/lessons', authenticateToken, (req: any, res) => {
    // Mock lessons data
    const lessons = [
      { id: 'alphabets', title: 'Alphabets (A-Z)', type: 'alphabet' },
      { id: 'words', title: 'Common Words', type: 'word' },
      { id: 'sentences', title: 'Basic Sentences', type: 'sentence' }
    ];
    res.json(lessons);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
